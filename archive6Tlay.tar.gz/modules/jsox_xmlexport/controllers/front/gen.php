<?php

class jsox_xmlexportGenModuleFrontController extends ModuleFrontController
{

	public function __construct()
	{
		$this->prefix = 'genxml';
		parent::__construct();
	}
}
