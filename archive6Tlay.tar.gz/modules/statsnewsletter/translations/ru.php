<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_ffb7e666a70151215b4c55c6268d7d72'] = 'Рассылка';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_5106250927c6e24c99601968284066de'] = 'На панель статистики добавляется график с динамикой подписки на рассылку.';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_61a898af87607e3f4d41c3613d8761c7'] = 'Регистраций клиентов:';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_7fe462207f98012d9ff00cf0e6633c94'] = 'Регистраций посетителей: ';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_64342cd480b27dfeefb08bace6e82fdc'] = 'Всего:';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_998e4c5c80f27dec552e99dfed34889a'] = 'Экспорт в CSV';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_cf74c2815ab62be1efa55a4a5d3f46a4'] = 'Статистика рассылки';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_4b6f7d34a58ba399f077685951d06738'] = 'Клиенты';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_ae5d01b6efa819cc7a7c05a8c57fcc2c'] = 'Посетители';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_130c5b3473c57faa76e2a1c54e26f88e'] = 'Всего';
