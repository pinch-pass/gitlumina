<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{dashgoals}prestashop>dashgoals_50698c5b8ffaf2b7dd089898a244a668'] = 'Pulpit Celów';
$_MODULE['<{dashgoals}prestashop>dashgoals_14089da5dd6132b674d9829b136efff9'] = 'Dodaje blok z prognozami dla Twojego sklepu.';
$_MODULE['<{dashgoals}prestashop>dashgoals_86f5978d9b80124f509bdb71786e929e'] = 'Styczeń';
$_MODULE['<{dashgoals}prestashop>dashgoals_659e59f062c75f81259d22786d6c44aa'] = 'Luty';
$_MODULE['<{dashgoals}prestashop>dashgoals_fa3e5edac607a88d8fd7ecb9d6d67424'] = 'Marzec';
$_MODULE['<{dashgoals}prestashop>dashgoals_3fcf026bbfffb63fb24b8de9d0446949'] = 'Kwiecień';
$_MODULE['<{dashgoals}prestashop>dashgoals_195fbb57ffe7449796d23466085ce6d8'] = 'Maj';
$_MODULE['<{dashgoals}prestashop>dashgoals_688937ccaf2a2b0c45a1c9bbba09698d'] = 'Czerwiec';
$_MODULE['<{dashgoals}prestashop>dashgoals_1b539f6f34e8503c97f6d3421346b63c'] = 'Lipiec';
$_MODULE['<{dashgoals}prestashop>dashgoals_41ba70891fb6f39327d8ccb9b1dafb84'] = 'Sierpień';
$_MODULE['<{dashgoals}prestashop>dashgoals_cc5d90569e1c8313c2b1c2aab1401174'] = 'Wrzesień';
$_MODULE['<{dashgoals}prestashop>dashgoals_eca60ae8611369fe28a02e2ab8c5d12e'] = 'Październik';
$_MODULE['<{dashgoals}prestashop>dashgoals_7e823b37564da492ca1629b4732289a8'] = 'Listopad';
$_MODULE['<{dashgoals}prestashop>dashgoals_82331503174acbae012b2004f6431fa5'] = 'Grudzień';
$_MODULE['<{dashgoals}prestashop>dashgoals_e7935ae6c516d89405ec532359d2d75a'] = 'Ruch';
$_MODULE['<{dashgoals}prestashop>dashgoals_233d48e63da77b092da350559d2f8382'] = 'wizyty';
$_MODULE['<{dashgoals}prestashop>dashgoals_3bb1503332637805beddb73a2dd1fe1b'] = 'Konwersja';
$_MODULE['<{dashgoals}prestashop>dashgoals_71241798130f714cbd2786df3da2cf0b'] = 'Średnia wartość koszyka';
$_MODULE['<{dashgoals}prestashop>dashgoals_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Sprzedaż';
$_MODULE['<{dashgoals}prestashop>dashgoals_9ac642c5ef334ea05256563f921bb304'] = 'Cel osiągnięty';
$_MODULE['<{dashgoals}prestashop>dashgoals_7c103c9bbbaecee07ca898ed65667cbf'] = 'Cel nie osiągnięty';
$_MODULE['<{dashgoals}prestashop>dashgoals_eb233580dc419f03df5905f175606e4d'] = 'Cel ustalony:';
$_MODULE['<{dashgoals}prestashop>config_254f642527b45bc260048e30704edb39'] = 'Konfiguracja';
$_MODULE['<{dashgoals}prestashop>config_e7935ae6c516d89405ec532359d2d75a'] = 'Ruch';
$_MODULE['<{dashgoals}prestashop>config_e4c3da18c66c0147144767efeb59198f'] = 'Stopa konwersji';
$_MODULE['<{dashgoals}prestashop>config_8c804960da61b637c548c951652b0cac'] = 'Średnia ilość koszyków';
$_MODULE['<{dashgoals}prestashop>config_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Sprzedaż';
$_MODULE['<{dashgoals}prestashop>config_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{dashgoals}prestashop>dashboard_zone_two_89c1265be62d3ba835a3d963db5956b0'] = 'Prognoza';
$_MODULE['<{dashgoals}prestashop>dashboard_zone_two_f1206f9fadc5ce41694f69129aecac26'] = 'Konfiguruj';
$_MODULE['<{dashgoals}prestashop>dashboard_zone_two_63a6a88c066880c5ac42394a22803ca6'] = 'Odśwież';
$_MODULE['<{dashgoals}prestashop>dashboard_zone_two_e7935ae6c516d89405ec532359d2d75a'] = 'Ruch';
$_MODULE['<{dashgoals}prestashop>dashboard_zone_two_3bb1503332637805beddb73a2dd1fe1b'] = 'Konwersja';
$_MODULE['<{dashgoals}prestashop>dashboard_zone_two_8c804960da61b637c548c951652b0cac'] = 'Średnia ilość koszyków';
$_MODULE['<{dashgoals}prestashop>dashboard_zone_two_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Sprzedaż';


return $_MODULE;
