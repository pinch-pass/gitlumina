<?php

/*
 * Stworzono przez SEIGI http://pl.seigi.eu/
 * Wszelkie prawa zastrzeżone.
 * Zabrania się modyfikacji używania i udostępniania kodu bez zgody lub odpowiedniej licencji.
 * Utworzono  : Jul 31, 2016
 * Author     : SEIGI - Grzegorz Zawadzki <kontakt@seigi.eu>
 */

namespace pricewars2;
class pricewarsSkipException extends \Exception {
}
