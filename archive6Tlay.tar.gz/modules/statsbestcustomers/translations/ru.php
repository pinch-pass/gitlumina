<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_4f29d8c727dcf2022ac241cb96c31083'] = 'Вернулась пустая запись';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_f5c493141bb4b2508c5938fd9353291a'] = 'Показано %1$s из %2$s';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_77587239bf4c54ea493c7033e1dbf636'] = 'Фамилия';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_bc910f8bdf70f29374f496f05be0330c'] = 'Имя';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'E-mail';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_d7e637a6e9ff116de2fa89551240a94d'] = 'Посещений';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_ec1ee973b8947391f8f014c76ac7379f'] = 'Подтвержденные заказы';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_1ff1b62d08d1195f073c6adac00f1894'] = 'Потрачено';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_8b83489bd116cb60e2f348e9c63cd7f6'] = 'Лучшие клиенты';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_9a1643c70b51526dd35d546ef8e17b87'] = 'Добавляет список лучших клиентов на панель статистики.';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_6602bbeb2956c035fb4cb5e844a4861b'] = 'Руководство';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_cb21e843b037359d0fb5b793fccf964f'] = 'Поддержка лояльности клиентов';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_c01d21a09f02b8e661114db60a0f60d4'] = 'Удержание клиента выгоднее, чем получение нового. Таким образом, необходимо укреплять лояльность клиентов, чтобы они захотели вернуться к вам.';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_197bad7ad08abfd1dc45ab92f96f155d'] = 'Сарафанное радио - также средство для получения новых, удовлетворенных клиентов; недовольный клиент не посоветует вас друзьям.';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_bf0d87b5aa8d331563ee61f2ac82069d'] = 'Для того, чтобы достичь этого, вы можете организовать:';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_397a5e109a5897ee7d699050cbc93347'] = 'Разовые акции : коммерческие бонусы (персональные спецпредложения товаров и услуг), некоммерческие бонусы (приоритетная обработка заказа или товара), денежные бонусы (подарочные чеки, скидочные купоны, денежные вознаграждения).';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_4bc24eed56e0ba89fc3ab4e094d18d8a'] = 'Постоянные акции: накопительные карты или баллы, позволяющие не только укрепить отношения с клиентом, но и предложить ему преимущества в виде персональных скидок и предложений.';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_2f408c42912e3afe23a0e4adcbe34b96'] = 'Эти мероприятия побуждают клиентов чаще посещать ваш магазин и совершать покупки.';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_998e4c5c80f27dec552e99dfed34889a'] = 'Экспорт в CSV';
