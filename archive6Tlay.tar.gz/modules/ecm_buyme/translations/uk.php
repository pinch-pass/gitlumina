<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ecm_buyme}prestashop>buyme_6b8d170f0282fd77cff979d53afd6ec9'] = 'Купити за один кляць';
